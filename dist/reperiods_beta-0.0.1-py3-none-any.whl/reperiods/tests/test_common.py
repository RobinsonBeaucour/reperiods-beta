import pytest

@pytest.mark.Imports
def test_import():
    import paeendas